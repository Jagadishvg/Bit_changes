import React from 'react';
import { AddCoupon } from './add-coupon';

export const BasicAddCoupon = () => {
  return (
    <AddCoupon>hello world!</AddCoupon>
  );
}
