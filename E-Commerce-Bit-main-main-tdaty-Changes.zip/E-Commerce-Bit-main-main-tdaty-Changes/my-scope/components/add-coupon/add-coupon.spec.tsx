import React from 'react';
import { render } from '@testing-library/react';
import { BasicAddCoupon } from './add-coupon.composition';

it('should render with the correct text', () => {
  const { getByText } = render(<BasicAddCoupon />);
  const rendered = getByText('hello world!');
  expect(rendered).toBeTruthy();
});
