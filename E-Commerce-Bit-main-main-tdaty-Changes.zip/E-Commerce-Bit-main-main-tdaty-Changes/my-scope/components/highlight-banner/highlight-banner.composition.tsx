import React from 'react';
import { HighlightBanner } from './highlight-banner';

export const BasicHighlightBanner = () => {
  return (
    <HighlightBanner>hello world!</HighlightBanner>
  );
}
