import React, { ReactNode } from 'react';

export type HighlightBannerProps = {
  /**
   * a node to be rendered in the special component.
   */
   bannerData: {  
    title: string;     
    description: string;     
    buttonText: string;      
    contentPosition: string;     
    imageSrc: string;     
    imageAltText: string;      
  };

  // children?: ReactNode;
};

export function HighlightBanner({ bannerData }: HighlightBannerProps) {
  return (
    <section className={`highlight-banner banner-${bannerData.contentPosition} py-5`}>
      <div className="container">
        {
            bannerData.title ?
            <h1 className="mb-3">{bannerData.title}</h1> : ''
        }
        {
            bannerData.description ?
            <p className="mb-4">{bannerData.description}</p> : ''
        }
        {
            bannerData.buttonText ? <button className="btn btn-primary">{bannerData.buttonText}</button> : ''
        }
      </div>
    </section>
    );
}
