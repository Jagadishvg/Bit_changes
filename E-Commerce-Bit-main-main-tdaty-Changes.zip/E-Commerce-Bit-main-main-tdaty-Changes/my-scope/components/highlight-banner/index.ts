export { HighlightBanner } from './highlight-banner';
export type { HighlightBannerProps } from './highlight-banner';
