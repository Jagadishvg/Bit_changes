export { Footer } from './footer';
export type { FooterProps } from './footer';
