import React, { PureComponent } from "react";

export default class Comp {
    render() {
        return (
            <div>
              <h6>Some Component</h6>
            </div>
        );
    }
}