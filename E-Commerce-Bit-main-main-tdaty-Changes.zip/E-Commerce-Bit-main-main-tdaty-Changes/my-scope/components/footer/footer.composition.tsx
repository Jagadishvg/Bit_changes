import React from 'react';
import { Footer } from './footer';

export const BasicFooter = () => {
  return (
    <Footer>hello world!</Footer>
  );
}
