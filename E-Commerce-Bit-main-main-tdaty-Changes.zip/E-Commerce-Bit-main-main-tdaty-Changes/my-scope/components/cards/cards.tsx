import React, { ReactNode } from 'react';
// import OwlCarousel from 'react-owl-carousel'; 
// import 'owl.carousel/dist/assets/owl.carousel.css'; 
import {PlainCard} from "@my-scope/components.plain-card";
import {ProductCard} from "@my-scope/components.product-card";
export type CardsProps = {
  /**
   * a node to be rendered in the special component.
   */
   sectionData: Array<{
    title: string;
    description:string;
    buttonText?: string;
   }>

   sectionConfig:{
    sectionType:string;
    cardShape: string;
    cardSize: string;
    cardType: string;
   }
 
};

export function Cards({ sectionData, sectionConfig }: CardsProps) {
 const navText =  [
    '<i class="prev-btn fas fa-chevron-left"></i>',
    '<i class="next-btn fas fa-chevron-right"></i>'
];
const responsiveMedium ={
    0: {
        items: 1,
        nav: false
    },
    576: {
        items: 2,
        nav: false
    },
    768: {
        items: 3,
        nav: true
    },
    992: {
        items: 4,
        nav: true
    }
};
const responsiveSmall = {
    0: {
        items: 2,
        nav: false
    },
    576: {
        items: 3,
        nav: false
    },
    768: {
        items: 4,
        nav: true
    },
    992: {
        items: 6,
        nav: true
    }
};
const renderCards = (card)=> {
  if (sectionConfig && sectionConfig.cardType === 'product' ) {
      return <ProductCard key={card.productId} cardData={card} cardShape={sectionConfig.cardShape}> </ProductCard>;
  }
  return <PlainCard key={card.title} cardData={card} cardShape={sectionConfig.cardShape}> </PlainCard>
}
const gridClass = sectionConfig && sectionConfig.cardSize && sectionConfig.cardSize === 'small'? 'col-6 col-lg-2 col-md-3 col-sm-4' : 'col-12 col-lg-4 col-md-6 col-sm-6'

if (!(sectionData && sectionConfig)){
  return <div></div>
}
else{

  return (
    // <section className="container py-2 py-lg-5">
    <section>
    {/* <div className="row gy-5 gx-5"> */}
    {/* <h1 className="title mt-0">{sectionData.title}</h1> */}
    {/* {sectionData && sectionData.map(card => ( */}

      <div className={gridClass}>
        {renderCards(sectionData)}
      </div>
    {/* ))} */}
    {/* </div> */}

</section>
  );
}
}
