import React from 'react';
import { Cards } from './cards';

export const BasicCards = () => {
  return (
    <Cards>hello world!</Cards>
  );
}
