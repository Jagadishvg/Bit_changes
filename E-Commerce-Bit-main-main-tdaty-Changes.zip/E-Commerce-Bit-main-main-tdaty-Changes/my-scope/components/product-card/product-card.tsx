import React, { ReactNode, useContext , useState } from 'react';
import { CartContext } from '@my-scope/context.cart';

export type ProductCardProps = {
  /**
   * a node to be rendered in the special component.
   */
  cardShape:string;
  cardData: 
  {     
    productDetails:{
      caption: string;     
    badge: string;     
    totalRatings: string;     
    price: string;   
    productName: string;     
    discountPrice: string;     
  };
  imageSrc: string;       
      imageAltText: string;  
       
  };
  

}

  // children?: ReactNode;

export function ProductCard({ cardData, cardShape  }: ProductCardProps) {
  const { addToCart } = useContext(CartContext);
  const [isAdded, setIsAdded] =useState(false);
  const handleAddToCart = (event: React.MouseEvent<HTMLAnchorElement, MouseEvent>) => {
    event.preventDefault();
    const productWithQuantity = { ...cardData, quantity: 1 };   
    addToCart(productWithQuantity);
    setIsAdded(true);
    setTimeout(() => {
      setIsAdded(false);
    }, 1500);
  };


  return (
    <div className={`product-card d-flex flex-column ${cardShape}`}>
        <div className="card-image">
          <img src={cardData.imageSrc} alt={cardData.imageAltText} />
          <span className="highlight-badge py-1 px-3">{cardData.productDetails.badge}</span>
          <div className="product-ratings d-flex py-1 px-3">
            <div className="product-rating flex-grow-1">
              <span><i className="fas fa-star"></i></span>
              <span><i className="fas fa-star"></i></span>
              <span><i className="fas fa-star"></i></span>
              <span><i className="fas fa-star"></i></span>
              <span><i className="fas fa-star-half-alt"></i></span>
            </div>
            <div>{cardData.productDetails.totalRatings} Ratings</div>
          </div>
        </div>
        <div className="product-details flex-grow-1 p-3 d-flex flex-column">
          <div className="d-flex flex-grow-1">
            <div className="flex-grow-1">
              <div className="fs-6 fw-bold">{cardData.productDetails.productName}</div>
              <span className="description">{cardData.productDetails.caption}</span>
            </div>
            <div>
                <div className="fs-5">{cardData.productDetails.discountPrice}</div>
                <div className="fade-price text-decoration-line-through m-0">{cardData.productDetails.price}</div>
            </div>
          </div>
          <hr />
          <div className="d-flex">
          <a
            className={`custom-link ${isAdded ? 'disabled' : ''}`}
            onClick={!isAdded ? handleAddToCart : undefined}
            href={isAdded ? undefined : ''}
            style={{ cursor: 'pointer' }}
          >
            <i className="fas fa-shopping-cart me-2"></i>
            {isAdded ? 'Added to Cart' : 'Add to Cart'}
          </a>
          <a className="link" href="#">
            <i className="far fa-heart"></i>
          </a>
          </div>
        </div>
      </div>
  );
}
