export { ProductCard } from './product-card';
export type { ProductCardProps } from './product-card';
