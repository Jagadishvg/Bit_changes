import React from 'react';
import { ProductCard } from './product-card';

export const BasicProductCard = () => {
  return (
    <ProductCard>hello world!</ProductCard>
  );
}
