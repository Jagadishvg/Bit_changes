import React from 'react';
import { PlainCard } from './plain-card';

export const BasicPlainCard = () => {
  return (
    <PlainCard>hello world!</PlainCard>
  );
}
