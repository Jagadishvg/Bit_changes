export { PlainCard } from './plain-card';
export type { PlainCardProps } from './plain-card';
