import React, { ReactNode } from 'react';
import { useNavigate } from 'react-router-dom';

export type PlainCardProps = {
  /**
   * a node to be rendered in the special component.
   *
   */
  cardShape: string;
  cardData: {
    title: string;
    description: string;
    buttonText: string;
    imageSrc: string;
    imageAltText: string;
    productId: string;
  };
  // children?: ReactNode;
};

export function PlainCard({ cardData, cardShape }: PlainCardProps) {
  const navigate = useNavigate();

  const handleBuyNowClick = () => {
    navigate(`/product/${cardData.productId}`);
  };
  return (
    <div className={`highlight-card ${cardShape}`}>
      <div className="card-image mb-3">
        <img src={cardData.imageSrc} alt={cardData.imageAltText} />
        {cardData.buttonText ? (
          <div className="card-content px-4 py-4 d-flex align-items-center justify-content-center flex-wrap">
            <button
              className="btn btn-outline-primary"
              onClick={handleBuyNowClick}
            >
              {cardData.buttonText}
            </button>
          </div>
        ) : (
          ''
        )}
      </div>
      {cardData.title ? (
        <div className="fs-5 fw-bold">{cardData.title}</div>
      ) : (
        ''
      )}
      {cardData.description ? (
        <p className="fade-text">{cardData.description}</p>
      ) : (
        ''
      )}
    </div>
  );
}
