import React from 'react';
import { render } from '@testing-library/react';
import { BasicSummary } from './summary.composition';

it('should render with the correct text', () => {
  const { getByText } = render(<BasicSummary />);
  const rendered = getByText('hello world!');
  expect(rendered).toBeTruthy();
});
