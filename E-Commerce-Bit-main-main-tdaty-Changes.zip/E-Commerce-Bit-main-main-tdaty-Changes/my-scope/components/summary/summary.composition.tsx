import React from 'react';
import { Summary } from './summary';

export const BasicSummary = () => {
  return (
    <Summary>hello world!</Summary>
  );
}
