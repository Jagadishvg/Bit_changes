import React from 'react';
import { CardSection } from './card-section';

export const BasicCardSection = () => {
  return (
    <CardSection>hello world!</CardSection>
  );
}
