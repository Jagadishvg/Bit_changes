import React, { ReactNode } from 'react';
//import OwlCarousel from 'react-owl-carousel'; 
import { useNavigate, Link } from 'react-router-dom';
import 'owl.carousel/dist/assets/owl.carousel.css'; 
import {PlainCard} from "@my-scope/components.plain-card";
import {ProductCard} from "@my-scope/components.product-card";
import {ProductDetails} from '@my-scope/pages.product-details';
export type CardSectionProps = {
  /**
   * a node to be rendered in the special component.
   */
   sectionData: {
    title: string;
    description:string;
    buttonText?: string;
    
    all_items:Array<{
      title:string
    }>;
   }

   sectionConfig:{
    title:string;
    sectionType:string;
    cardShape: string;
    cardSize: string;
    cardType: string;
   }
 
  // children?: ReactNode;
};
 


export function CardSection({ sectionData, sectionConfig }: CardSectionProps) {
// const navigate = useNavigate();

// const handleClick = function () {
//     navigate("/product");
// }
const  navText =  [
    '<i class="prev-btn fas fa-chevron-left"></i>',
    '<i class="next-btn fas fa-chevron-right"></i>'
];
const responsiveMedium ={
    0: {
        items: 1,
        nav: false
    },
    576: {
        items: 2,
        nav: false
    },
    768: {
        items: 3,
        nav: true
    },
    992: {
        items: 4,
        nav: true
    }
};
const responsiveSmall = {
    0: {
        items: 2,
        nav: false
    },
    576: {
        items: 3,
        nav: false
    },
    768: {
        items: 4,
        nav: true
    },
    992: {
        items: 6,
        nav: true
    }
};

const gridClass = (sectionConfig && sectionConfig.cardSize && sectionConfig.cardSize  === 'small')? 'col-6 col-lg-2 col-md-3 col-sm-4' : 'col-12 col-lg-3 col-md-4 col-sm-6'
const isActivityComponent = (sectionData && sectionData.title && sectionData.title === 'Activity');
const renderCards = (card) => {
  if (sectionConfig && sectionConfig.cardType === 'product' ) {
      return <ProductCard key={card.productId} cardData={card} cardShape={sectionConfig.cardShape}> </ProductCard>;
  }

  return <PlainCard key={card.title} cardData={card} cardShape={sectionConfig.cardShape}> </PlainCard>
};

// const ProductList = ({ products }) => {
    if (!(sectionData && sectionConfig)){
        return <div></div>
    }
    else{

    return (
    <section className="container py-4 py-lg-5">
              {console.log("CARD SHAPE IS", sectionConfig.cardType)}
        <div className="mb-4 mb-lg-5">
          <div className="title-wrapper mb-2">
            <h1 className="title">{sectionConfig.title}</h1>
            {console.log(sectionConfig.title, "TITLE >>>")}
            {console.log(sectionConfig.description, "DESCRIPTION >>>")}
            {/* {products.map(product => (
                    <Link to={`/product/${product.id}`}>
                        {sectionData.buttonText ? <span><button onClick={handleClick} className="btn btn-outline-primary">{sectionData.buttonText}</button></span> : ''}
                    </Link>

                    ))}
                    <p>{sectionData.description}</p> */}
                </div>
        </div>
      {
        sectionData.sectionType === 'carousel' ?
            <div className="card-carousel mb-5">
            {/* <OwlCarousel navText={this.navText} responsive={sectionData.cardSize === 'small'? this.responsiveSmall : this.responsiveMedium } margin={24} autoplay={isActivityComponent} loop={isActivityComponent} nav={true} autoplayTimeout={2000} autoplayHoverPause={true}>  */}
            <h1 className="title">{sectionData.title}</h1>
                {sectionData.all_items && sectionData.all_items.slice(0,6).map(card => (
                    <div className="pb-2">
                        {renderCards(card)}
                    </div>
            ))}
            {/* </OwlCarousel> */}
            </div>
        : 
            <div className="row gy-4">
            {sectionData.all_items && sectionData.all_items.slice(0,6).map(card => (
              <div className={gridClass}>
                {renderCards(card)}
              </div>
            ))}
            </div>
        }
    </section>
    );
    }
    }
