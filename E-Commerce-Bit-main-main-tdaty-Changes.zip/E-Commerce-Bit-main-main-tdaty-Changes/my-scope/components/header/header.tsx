import React, { ReactNode, useContext } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min.js';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
  faBars,
  faSearch,
  faHeart,
  faShoppingCart,
  faUserAlt,
} from '@fortawesome/free-solid-svg-icons';
import { NavLink } from 'react-router-dom';
import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { CartContext } from '@my-scope/context.cart';
import { SearchContext } from '@my-scope/context.search';
import { CategoryContext } from '@my-scope/context.category';
// import '@my-scope/apps.root-app/app.scss';
// import './header.css';
// import './headerone.css';

export type HeaderProps = {
  /**
   * a node to be rendered in the special component.
   */
  children?: ReactNode;
};

export function Header({ children }: HeaderProps) {
  const {cart } = useContext(CartContext);

  const totalQuantity = cart.reduce((total, item) => total + parseInt(item.quantity, 10), 0);

  const [searchTerm, setSearchTerm] = useState('');

  const navigate = useNavigate();

  const [mockData, mocksetData] = useState({all_items:[]});

  const { searchProduct } = useContext(SearchContext);

  const { setCategory } = useContext(CategoryContext) || {};
  
  const [categories, setCategories] = useState<string[]>([]);


  useEffect(() => {
    fetch('http://127.0.0.1:5500/my-scope/assets/Mock_plants.json')
      .then((response) => response.json())

      .then((jsonData) => mocksetData(jsonData))

      .catch((error) => console.error('Error:', error));
  }, []);

  const handleInputChange = (event) => {
    setSearchTerm(event.target.value);
  };

  const handleKeyPress = (event) => {
    if (event.key === 'Enter') {
      handleSearch(searchTerm);
    }
  };

  const handleSearch = (searchTerm)=>{
    const filteredProducts = mockData.all_items.filter((product) =>      
    product.title.toLowerCase().includes(searchTerm.toLowerCase())     
  );
  searchProduct(filteredProducts,searchTerm);
  navigate('/search')
  }

  useEffect(() => {
    fetch('http://127.0.0.1:5500/my-scope/assets/Mock.json')
      .then((response) => response.json())
      .then((data) => {
        console.log('Fetched Data:', data);
        const uniqueCategories: string[] = Array.from(
          new Set(data.all_items.map((item) => item.productDetails.category))
        );
        setCategories(uniqueCategories);
      })
      .catch((error) => console.error('Error fetching categories:', error));
  }, []);

  const handleCategoryChange = (category: string) => {
    setCategory(category);
  };
  return (

    <div>
      {/* {children} */}
      <header>
        <nav className="navbar navbar-expand-lg navbar-light fixed-top">
          <div className="container">
            <button
              className="navbar-toggler"
              type="button"
              data-bs-toggle="collapse"
              data-bs-target="#navbarSupportedContent"
              aria-controls="navbarSupportedContent"
              aria-expanded="false"
              aria-label="Toggle navigation"
            >
              <i className="fas fa-bars"></i>
              <i>
                <FontAwesomeIcon icon={faBars} />
              </i>
            </button>
            <NavLink className="navbar-brand" to="/">
              <img
                className="logo-img"
                alt="LOGO"
                src="https://logos-world.net/wp-content/uploads/2021/08/Zensar-Emblem.png"
              />
            </NavLink>
            <div
              className="collapse navbar-collapse"
              id="navbarSupportedContent"
            >
              <ul className="navbar-nav me-auto mb-2 mb-lg-0">
                <li className="nav-item">
                  <NavLink
                    className="nav-link active"
                    aria-current="page"
                    to="/"
                  >
                    Home
                  </NavLink>
                </li>
                {/* <li className="nav-item">
                  <NavLink
                    className="nav-link"
                    aria-current="page"
                    to="/product"
                  >
                    Product Page
                  </NavLink>
                </li> */}
                <li className="nav-item dropdown">
                  <NavLink
                    className="nav-link dropdown-toggle"
                    to="/"
                    id="navbarDropdown"
                    role="button"
                    data-bs-toggle="dropdown"
                    aria-expanded="false"
                  >
                    Pages
                  </NavLink>
                  <ul
                    className="dropdown-menu"
                    aria-labelledby="navbarDropdown"
                  >
                    <li>
                      <NavLink className="dropdown-item" to="/home2">
                        Home 2
                      </NavLink>
                    </li>
                    <li>
                      <NavLink className="dropdown-item" to="/checkout">
                        Checkout
                      </NavLink>
                    </li>
                    {/* <li>
                      <NavLink className="dropdown-item" to="/product">
                        Product Details
                      </NavLink>
                    </li> */}
                  </ul>
                </li>
                <li className="nav-item dropdown">
                  <NavLink
                    className="nav-link dropdown-toggle"
                    to="/"
                    id="navbarDropdown"
                    role="button"
                    data-bs-toggle="dropdown"
                    aria-expanded="false"
                  >
                    Categories
                  </NavLink>
                  <ul className="dropdown-menu" aria-labelledby="navbarDropdown">
              {categories.map((category) => (
                <li key={category}>
                  <NavLink
                    className="dropdown-item"
                    to={`/category/${category.toLowerCase()}`}
                    onClick={() => handleCategoryChange(category)}
                  >
                    {category}
                  </NavLink>
                </li>
              ))}
            </ul>
          </li>
                <li className="nav-item">
                  <NavLink className="nav-link" to="/article">
                    About Us
                  </NavLink>
                </li>
              </ul>
              {/* <form className="d-flex flex-row">
                <input
                  className="form-control me-2"
                  type="search"
                  placeholder="Search"
                  aria-label="Search"
                />
                <button className="btn btn-outline-success" type="submit">
                  Search
                </button>
              </form> */}
            </div>
            <div className="nav-icons">
              <ul>
                <li className="nav-icon">
                  <NavLink
                    to="/"
                    data-bs-toggle="collapse"
                    data-bs-target="#collapseExample"
                    aria-expanded="false"
                    aria-controls="collapseExample"
                  >
                    <i>
                      <FontAwesomeIcon icon={faSearch} />
                    </i>
                  </NavLink>
                </li>
                <li className="nav-icon">
                  <NavLink to="/wishlist">
                    <i>
                      <FontAwesomeIcon icon={faHeart} />
                      <span className="notification-dot"></span>
                    </i>
                  </NavLink>
                </li>
                <li className="nav-icon">
                  <NavLink to="/cart">
                  {totalQuantity >0 ?(
                    <>
                    <i>
                      <FontAwesomeIcon icon={faShoppingCart} />
                      <span className="notification-dot"></span>
                    </i>
                 
                    <span className="count-badge fw-bold">{totalQuantity}</span>
                    </>
                  ):(
                    <i>
                      <FontAwesomeIcon icon={faShoppingCart} />
                    </i>
                  )
                    }
 
                  </NavLink>
                </li>
                {/* <li className="nav-icon">
                  <NavLink to="/cart">
                    <i>
                      <FontAwesomeIcon icon={faShoppingCart} />
                      <span className="notification-dot"></span>
                    </i>
                    <span className="count-badge fw-bold">{totalQuantity >0 ?totalQuantity:0}</span>

                  </NavLink>
                </li> */}
                {/* <li className="nav-icon">
                  <NavLink  to="/"><i className="fas fa-user-alt"></i>
                  </NavLink >
                </li> */}
                <li className="nav-icon profile-icon">
                  <NavLink
                    to="/login"
                    // //onClick={this.handleProfileClick}
                    // data-bs-toggle="collapse"
                    // // data-bs-target="#collapseExample"
                    // aria-expanded="false"
                    // aria-controls="collapseExample"
                  >
                    <i>
                      <FontAwesomeIcon icon={faUserAlt} />
                    </i>
                  </NavLink>
                  {/* {this.props.showProfile && (
                    <span className="">
                      <Profile />
                    </span>
                  )} */}
                </li>
                {/* <li className="nav-icon"><NavLink to="/login" >Login</NavLink ></li>
                <li className="nav-icon"><NavLink to="/signup" >SignUp</NavLink ></li> */}
              </ul>
            </div>
          </div>
          <div className="sub-nav collapse" id="collapseExample">
            <hr className="mt-0 mb-0 pt-0 pb-0 container" />
            <div className="container py-2">
              <div className="row gy-2">
                <div className="col-12 col-md-6 mx-auto">
                  <div className="input-group">
                    <input
                      type="text"
                      className="form-control"
                      placeholder="What are you searching for?"
                      aria-label="Recipient's username"
                      aria-describedby="button-addon2"
                      value={searchTerm}
                      onChange={handleInputChange}
                      onKeyPress={handleKeyPress}
                    />
                    <button
                      className="btn btn-primary"
                      type="button"
                      id="button-addon2"
                      // onClick={handleSearch}
                    >
                      <i>
                        <FontAwesomeIcon icon={faSearch} />
                      </i>
                    </button>
                    {/* <input type="text" className="form-control" placeholder="What are you searching for?" aria-label="Recipient's username" aria-describedby="button-addon2" />
                    <button className="btn btn-primary" type="button" id="button-addon2"><i><FontAwesomeIcon icon={faSearch} /></i></button> */}
                  </div>
                </div>
                {/* <div className="col-12 col-md-6 d-flex flex-wrap align-items-center">
                  <NavLink  className="link me-3" to="/searchtoys">Toys</NavLink >
                  <NavLink  className="link me-3" to="/searchcars">Cars</NavLink >
                  <NavLink  className="link me-3" to="/searchjeans">Jeans</NavLink >
                  <NavLink  className="link me-3" to="/searchshirts">Shirts</NavLink >
                </div> */}
              </div>
            </div>
          </div>
        </nav>
      </header>
    </div>
  );
}
