import React from 'react';
import { Header } from './header';

export const BasicHeader = () => {
  return (
    <Header>hello world!</Header>
  );
}
