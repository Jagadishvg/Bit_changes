import React, { ReactNode } from 'react';
import OwlCarousel from 'react-owl-carousel';
import 'owl.carousel/dist/assets/owl.carousel.css'; 
var $ = require('jquery')

export type BannerProps = {
  banners: Array<{        
    title: string;     
    description: string;     
    buttonText: string;  
    contentPosition: string;     
    imageSrc: string;     
    imageAltText: string;  
  }>;
  /**
   * a node to be rendered in the special component.
   */
  // children?: ReactNode;
};

export function Banner({ banners }: BannerProps) {
  const  navText =  [
      '<i class="prev-btn fas fa-chevron-left"></i>',
      '<i class="next-btn fas fa-chevron-right"></i>'
  ];
  const responsive = {
      0: {
          items: 1,
          nav: false
      },
      576: {
          items: 1,
          nav: false
      },
      768: {
          items: 1,
          nav: true
      }
  };
  const data = Array.from(banners);

  return (
<div>
{/* <OwlCarousel navText={navText} items={1} responsive={responsive} margin={0} autoplay={true} loop={true} nav={true} autoplayTimeout={4000} autoplayHoverPause={true} animateOut={'fadeOut'}>  */}
  {data.slice(0,1).map(banner => (
      <div className={`banner banner-${banner.contentPosition}`}>
        <img className="banner-image" src={banner.imageSrc} alt={banner.imageAltText} />
        <div className="banner-content container">
          <h1>{banner.title}</h1>
          <p className="banner-description">{banner.description}</p>
          <div><button className="btn btn-primary">{banner.buttonText}</button></div>
        </div>
      </div>
  ))}
{/* </OwlCarousel> */}
</div>
  );
}
