import React from 'react';
import { Banner } from './banner';

export const BasicBanner = () => {
  return (
    <Banner>hello world!</Banner>
  );
}
