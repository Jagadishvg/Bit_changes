export { OfferBanner } from './offer-banner';
export type { OfferBannerProps } from './offer-banner';
