import React, { ReactNode } from 'react';
 
type OfferBannerProps = {

  offerBanner: {

    text: string;

    buttonText: string;

  };

};
 
export function OfferBanner({ offerBanner }: OfferBannerProps) {

  return (

    <section className="highlight-banner banner-center py-4">

      <div className="container">

        <div className="d-inline-flex flex-wrap align-items-center">

          <h2 className="me-3 my-2">{offerBanner.text}</h2>

          <button className="btn btn-primary">{offerBanner.buttonText}</button>

        </div>

      </div>

    </section>

  );

}
