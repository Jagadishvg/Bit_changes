import React from 'react';
import { OfferBanner } from './offer-banner';

export const BasicOfferBanner = () => {
  return (
    <OfferBanner>hello world!</OfferBanner>
  );
}
