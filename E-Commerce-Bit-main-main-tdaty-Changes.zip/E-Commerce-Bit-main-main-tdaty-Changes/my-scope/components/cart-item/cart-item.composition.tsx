import React from 'react';
import { CartItem } from './cart-item';

export const BasicCartItem = () => {
  return (
    <CartItem>hello world!</CartItem>
  );
}
