import React from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter } from 'react-router-dom';
import { RootAppApp } from './app';


ReactDOM.render((
  <BrowserRouter>
    <RootAppApp />
  </BrowserRouter>
), document.getElementById('root'));

