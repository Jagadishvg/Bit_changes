import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Header } from '@my-scope/components.header';
import { Footer } from '@my-scope/components.footer';
import { Login } from '@my-scope/pages.login';
import { Home } from '@my-scope/pages.home';
import { ProductDetails } from '@my-scope/pages.product-details';
import { Cart } from '@my-scope/pages.cart';
import { Search } from '@my-scope/pages.search';
import { Category } from '@my-scope/pages.category';
import { CategoryProvider } from '@my-scope/context.category';
import './app.scss';

export function RootAppApp() {
  return (
      <CategoryProvider>
        {/* header component */}
        <Header />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/login" element={<Login />} />
          <Route path="/product/:id" element={<ProductDetails />} />
          <Route path="/cart" element={<Cart />} />
          <Route path="/search" element={<Search />} />
          <Route path="/category/:categoryName" element={<Category />} />
          <Route path="/about">{/* about page component */}</Route>
        </Routes>
        {/* footer component */}
        <Footer />
      </CategoryProvider>
  );
}
