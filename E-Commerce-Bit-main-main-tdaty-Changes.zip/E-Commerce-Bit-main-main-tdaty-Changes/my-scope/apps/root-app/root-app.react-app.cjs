/** @type {import("@teambit/react.apps.react-app-types").ReactAppOptions} */
module.exports.default = {
  name: "root-app",
  entry: [require.resolve("./root-app.app-root")],
};