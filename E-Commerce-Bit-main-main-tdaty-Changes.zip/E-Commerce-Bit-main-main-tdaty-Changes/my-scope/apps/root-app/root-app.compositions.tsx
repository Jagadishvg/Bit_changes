import React from 'react';
import { MemoryRouter } from 'react-router-dom';
import { RootAppApp } from './app';
// import './app.scss'
import { CartProvider } from '@my-scope/context.cart';
import { SearchProvider } from '@my-scope/context.search';
export const RootAppBasic = () => {
  return (
    <MemoryRouter>
      <CartProvider>
        <SearchProvider>

      <RootAppApp />
        </SearchProvider>
      </CartProvider>
    </MemoryRouter>
  );
};
