import React, { ReactNode } from 'react';

export type MixinsProps = {
  /**
   * a node to be rendered in the special component.
   */
  children?: ReactNode;
};

export function Mixins({ children }: MixinsProps) {
  return (
    <div>
      {children}
    </div>
  );
}
