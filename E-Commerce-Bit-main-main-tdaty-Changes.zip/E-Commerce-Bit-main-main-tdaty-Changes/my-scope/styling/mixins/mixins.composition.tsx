import React from 'react';
import { Mixins } from './mixins';

export const BasicMixins = () => {
  return (
    <Mixins>hello world!</Mixins>
  );
}
