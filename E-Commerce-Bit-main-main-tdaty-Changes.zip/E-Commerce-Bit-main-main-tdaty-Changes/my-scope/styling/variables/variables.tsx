import React, { ReactNode } from 'react';

export type VariablesProps = {
  /**
   * a node to be rendered in the special component.
   */
  children?: ReactNode;
};

export function Variables({ children }: VariablesProps) {
  return (
    <div>
      {children}
    </div>
  );
}
