import React from 'react';
import { render } from '@testing-library/react';
import { BasicVariables } from './variables.composition';

it('should render with the correct text', () => {
  const { getByText } = render(<BasicVariables />);
  const rendered = getByText('hello world!');
  expect(rendered).toBeTruthy();
});
