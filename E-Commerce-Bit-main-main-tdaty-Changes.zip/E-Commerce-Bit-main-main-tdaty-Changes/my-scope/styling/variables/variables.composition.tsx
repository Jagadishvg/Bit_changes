import React from 'react';
import { Variables } from './variables';

export const BasicVariables = () => {
  return (
    <Variables>hello world!</Variables>
  );
}
