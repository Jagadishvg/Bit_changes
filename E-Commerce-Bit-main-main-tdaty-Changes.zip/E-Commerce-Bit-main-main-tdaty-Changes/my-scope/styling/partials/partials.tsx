import React, { ReactNode } from 'react';

export type PartialsProps = {
  /**
   * a node to be rendered in the special component.
   */
  children?: ReactNode;
};

export function Partials({ children }: PartialsProps) {
  return (
    <div>
      {children}
    </div>
  );
}
