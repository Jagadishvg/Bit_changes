import React from 'react';
import { Partials } from './partials';

export const BasicPartials = () => {
  return (
    <Partials>hello world!</Partials>
  );
}
