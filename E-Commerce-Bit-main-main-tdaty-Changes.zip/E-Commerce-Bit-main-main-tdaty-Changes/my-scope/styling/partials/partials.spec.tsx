import React from 'react';
import { render } from '@testing-library/react';
import { BasicPartials } from './partials.composition';

it('should render with the correct text', () => {
  const { getByText } = render(<BasicPartials />);
  const rendered = getByText('hello world!');
  expect(rendered).toBeTruthy();
});
