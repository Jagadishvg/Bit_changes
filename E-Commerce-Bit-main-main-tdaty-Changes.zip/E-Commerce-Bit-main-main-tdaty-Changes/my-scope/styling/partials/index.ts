export { Partials } from './partials';
export type { PartialsProps } from './partials';
