import React, { useContext } from 'react';
import { CategoryProvider } from './category-context-provider';
import { CategoryContext } from './category-context';

export function MockComponent() {
  const theme = useContext(CategoryContext);

  return <div style={{ color: theme.color }}>this should be {theme.color}</div>;
}

export const BasicThemeUsage = () => {
  return (
    <CategoryProvider color="blue">
      <MockComponent />
    </CategoryProvider>
  );
};
