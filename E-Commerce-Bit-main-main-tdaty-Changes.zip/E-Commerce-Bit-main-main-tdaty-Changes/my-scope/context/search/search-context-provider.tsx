import React, { useState, ReactNode } from 'react';
import { SearchContext } from './search-context';

export type SearchProviderProps = {
  children: ReactNode
};

export function SearchProvider({ children }: SearchProviderProps) {
  const [search, setSearch] = useState([]);
  const [searchTerm, setSearchTerm] = useState();

  const searchProduct = (item1,item2 ) => {
    setSearch(item1);
    setSearchTerm(item2);
  }


  const contextValue = {
    search,
    searchTerm,
    searchProduct,
  };

  return <SearchContext.Provider value={ contextValue }>{children}</SearchContext.Provider>
}
