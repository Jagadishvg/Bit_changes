import React, { useContext } from 'react';
import { SearchProvider } from './search-context-provider';
import { SearchContext } from './search-context';

export function MockComponent() {
  const theme = useContext(SearchContext);

  return <div style={{ color: theme.color }}>this should be {theme.color}</div>;
}

export const BasicThemeUsage = () => {
  return (
    <SearchProvider color="blue">
      <MockComponent />
    </SearchProvider>
  );
};
