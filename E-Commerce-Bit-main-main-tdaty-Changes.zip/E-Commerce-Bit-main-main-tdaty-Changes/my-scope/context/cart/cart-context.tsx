import { createContext } from 'react';

export type CartContextType = {
  cart: Array<any>;

  addToCart: (item: any) => void;

  increaseQuantity: (item: any) => void;

  decreaseQuantity: (item: any) => void;
  removeFromCart: (item: any) => void;
};

export const CartContext = createContext<CartContextType>({
  cart: [],

  addToCart: () => {},

  increaseQuantity: () => {},

  decreaseQuantity: () => {},
  removeFromCart: () => {},
});
