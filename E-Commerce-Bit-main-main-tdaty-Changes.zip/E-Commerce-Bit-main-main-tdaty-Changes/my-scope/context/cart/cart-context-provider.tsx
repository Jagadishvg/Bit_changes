import React, { useState, ReactNode } from 'react';

import { CartContext } from './cart-context';

export type CartProviderProps = {
  children: ReactNode;
};

export function CartProvider({ children }: CartProviderProps) {
  const [cart, setCart] = useState([]);

  const addToCart = (item) => {
    const existingItemIndex = cart.findIndex(
      (cartItem) => cartItem.productId === item.productId
    );
    if (existingItemIndex !== -1) {
      const updatedCart = [...cart];
      updatedCart[existingItemIndex].quantity = String(
        Number(updatedCart[existingItemIndex].quantity) + Number(item.quantity)
      );
      setCart(updatedCart);
    } else {
      setCart((prevCart) => [...prevCart, item]);
    }
  };

  const increaseQuantity = (productId: string) => {
    const updatedCart = cart.map((item) => {
      if (item.productId === productId) {
        item.quantity = String(Number(item.quantity) + 1);
      }
      return item;
    });
    setCart(updatedCart);
  };
  const decreaseQuantity = (productId) => {
    setCart((prevCart) =>
      prevCart.map((item) =>
        item.productId === productId && Number(item.quantity) > 1
          ? { ...item, quantity: String(Number(item.quantity) - 1) }
          : item
      )
      .filter((item)=>!(item.productId===productId && Number(item.quantity)===1))
    );
  };
  const removeFromCart = (productId: string) => {
    setCart((prevCart) =>
      prevCart.filter((item) => item.productId !== productId)
    );
  };
  const contextValue = {
    cart,
    addToCart,
    increaseQuantity,
    decreaseQuantity,
    removeFromCart,
  };


  return (
    <CartContext.Provider value={contextValue}>{children}</CartContext.Provider>
  );
}
