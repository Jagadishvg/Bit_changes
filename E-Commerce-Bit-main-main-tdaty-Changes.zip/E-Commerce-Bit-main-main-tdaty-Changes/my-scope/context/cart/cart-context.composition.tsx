import React, { useContext } from 'react';
import { CartProvider } from './cart-context-provider';
import { CartContext } from './cart-context';

export function MockComponent() {
  const theme = useContext(CartContext);

  return <div style={{ color: theme.color }}>this should be {theme.color}</div>;
}

export const BasicThemeUsage = () => {
  return (
    <CartProvider color="blue">
      <MockComponent />
    </CartProvider>
  );
};
