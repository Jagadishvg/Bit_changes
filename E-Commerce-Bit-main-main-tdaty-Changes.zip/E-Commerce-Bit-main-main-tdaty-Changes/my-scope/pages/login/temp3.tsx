// import { NavLink } from "react-router-dom";
import React, { ReactNode } from 'react';
import { useNavigate } from 'react-router-dom';
import { useState, useEffect } from 'react';
// import { GoogleLogin } from '@react-oauth/google';


export type LoginProps = {
  /**
   * a node to be rendered in the special component.
   */
  children?: ReactNode;
};

export function Login({ children }: LoginProps) {
 
  const [homeData, setData] = useState({ login: {}, signup:{} });

  useEffect(() => {
    fetch('http://127.0.0.1:5500/my-scope/assets/home.json')
      .then((response) => response.json())
      .then((jsonData) => setData(jsonData))
      .catch((error) => console.error('Error:', error));
  }, []);
  const contentPos = homeData.login.contentPosition === 'left' ? 'content-start' : homeData.login.contentPosition === 'right' ? 'content-end' : '';
  const navigate = useNavigate();
  const responseMessage = response => {
    console.log(response);
  };
  const errorMessage = error => {
    console.log(error);
  }; 
  function myFunction() {
    var x = document.getElementById("password");
    if (x.type === "password") {
      x.type = "text";
    } else {
      x.type = "password";
    }
  }
  function toHome() {
    navigate('/')
  }
  return<div className="login-wrapper">
  <img src={homeData.signup.imageSrc} alt={homeData.signup.imageAltText} />
  <div className={`content-wrapper ${contentPos}`}>
      <div className="container mt-5 px-0 py-5 d-flex">
          <div className="form-wrapper py-5 px-md-5 px-4">
              <div className="mb-4">
                  <h2>{homeData.signup.title}</h2>
                  <p>{homeData.signup.description}</p>
              </div>
              <div className="mb-3">
                  <label htmlFor="exampleFormControlInput1" className="form-label">Email address</label>
                  <input type="email" className="form-control" id="email" placeholder="name@example.com" />
              </div>
              <div className="mb-4">
                  <label htmlFor="exampleFormControlInput1" className="form-label">Password</label>
                  <input type="password" className="form-control" id="password" placeholder="Example@123" />
              </div>
              <div className="mb-4">
                  <label htmlFor="exampleFormControlInput1" className="form-label">Name</label>
                  <input type="text" className="form-control" id="name" placeholder="FirstName LastName" />
              </div>
              <div className="mb-4">
                  <label htmlFor="exampleFormControlInput1" className="form-label">DoB</label>
                  <input type="date" className="form-control" id="exampleFormControlInput1" placeholder="" />
              </div>
                  <label htmlFor="exampleFormControlInput1" className="form-label">Gender</label>
              <div className="mb-4">
                  <div className="form-check form-check-inline">
                      <input className="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="option1" />
                      <label className="form-check-label" htmlFor="inlineRadio1">Male</label>
                  </div>
                  <div className="form-check form-check-inline">
                      <input className="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="option2" />
                      <label className="form-check-label" htmlFor="inlineRadio2">Female</label>
                  </div>
                  <div className="form-check form-check-inline">
                      <input className="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio3" value="option3" />
                      <label className="form-check-label" htmlFor="inlineRadio3">Others</label>
                  </div>
              </div>
              <button className="btn btn-primary mb-3 me-3" onClick={toHome}>Sign Up</button>
              <a href="/login" className="link">Log In</a>
              <br />
              {/* <a href="#" className="link">Forgot password?</a> */}
              <hr />
              <div className="d-grid gap-3">
                  {/* <button className="btn btn-outline-primary full-width" type="button"><GoogleLogin onSuccess={responseMessage} onError={errorMessage} /></button> */}
                  <button className="btn btn-outline-primary full-width" type="button">Log in using Facebook</button>
              </div>
          </div>
      </div>
  </div>
</div>;
}
