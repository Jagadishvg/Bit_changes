import React, { ReactNode } from 'react';

import { useState, useEffect } from 'react';

import { AddCoupon } from '@my-scope/components.add-coupon';

import { Banner } from '@my-scope/components.banner';

import { HighlightBanner } from '@my-scope/components.highlight-banner';

import { CardSection } from '@my-scope/components.card-section';

export type HomeProps = {
  children?: ReactNode;
};

export function Home({ children }: HomeProps) {
  const [homeData, setData] = useState({
    banners: {},
    highlightBanner: {},
    bottomSection: {},
    sections: {},
    featureSection:{},
    newsletter:{}
  });
  const [mockData, mocksetData] = useState({
    cards:[]
  });

  useEffect(() => {
    fetch('http://127.0.0.1:5500/my-scope/assets/home2.json')
      .then((response) => response.json())

      .then((jsonData) => setData(jsonData))

      .catch((error) => console.error('Error:', error));
  }, []);
  useEffect(() => {
    fetch('http://127.0.0.1:5500/my-scope/assets/Mock_plants.json')
      .then((response) => response.json())

      .then((jsonData) => mocksetData(jsonData))

      .catch((error) => console.error('Error:', error));
  }, []);

  return (
    <div className="mb-5">
      <Banner banners={homeData.banners}></Banner>

      <CardSection sectionData={mockData} sectionConfig={homeData.featureSection} ></CardSection>
      <HighlightBanner bannerData={homeData.highlightBanner}></HighlightBanner>
      {homeData.sections && (homeData.sections.length>0)&& homeData.sections.slice(0,2).map((section, index) => (
        <div>
          
          <CardSection key={section.title} sectionData={mockData} sectionConfig={section}></CardSection>
          {index < homeData.sections.length - 1 ? (
            <hr className="container" />
          ) : (
            ''
          )}
        </div>
      ))}
      <div className="container">
        {homeData.bannerGrid ? (
          <div className="row banner-grid py-4 py-lg-5">
            {homeData.bannerGrid.map((banner, index) => (
              <div className="col-12 col-lg-6 col-md-12 col-sm-12 pb-4">
                <HighlightBanner bannerData={banner}></HighlightBanner>
              </div>
            ))}
          </div>
        ) : (
          ''
        )}
      </div>
      
      {homeData.newsletter ? (
        <section className="newsletter">
          <div className="container py-4 py-lg-5">
            <h2 className="text-light">{homeData.newsletter.title}</h2>
            <input
              type="text"
              name=""
              className="form-control"
              placeholder={homeData.newsletter.inputPlaceholder}
            />
            <button className="btn btn-primary">
              {homeData.newsletter.buttonText}
            </button>
          </div>
        </section>
      ) : (
        ''
      )}
      <CardSection sectionData={mockData} sectionConfig={homeData.bottomSection} ></CardSection>



    </div>
  );
}
