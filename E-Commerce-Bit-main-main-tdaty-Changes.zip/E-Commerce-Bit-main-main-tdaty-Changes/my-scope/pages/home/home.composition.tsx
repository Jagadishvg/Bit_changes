import React from 'react';
import { Home } from './home';

export const BasicHome = () => {
  return (
    <Home>hello world!</Home>
  );
}
