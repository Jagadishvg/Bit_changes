import React from 'react';
import { Search } from './search';

export const BasicSearch = () => {
  return (
    <Search>hello world!</Search>
  );
}
