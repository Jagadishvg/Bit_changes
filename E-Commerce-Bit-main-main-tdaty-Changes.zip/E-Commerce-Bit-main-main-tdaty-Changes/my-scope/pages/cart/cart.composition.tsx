import React from 'react';
import { Cart } from './cart';

export const BasicCart = () => {
  return (
    <Cart>hello world!</Cart>
  );
}
