import React, { ReactNode, useContext } from 'react';
import { CardSection } from '@my-scope/components.card-section';
import { CartItem } from '@my-scope/components.cart-item';
import { AddCoupon } from '@my-scope/components.add-coupon';
import { Summary } from '@my-scope/components.summary';
import { OfferBanner } from '@my-scope/components.offer-banner';
import { useState, useEffect } from 'react';
import { CartContext } from '@my-scope/context.cart';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faAngleLeft } from '@fortawesome/free-solid-svg-icons';
import { NavLink } from 'react-router-dom';

export type CartProps = {
  /**
   * a node to be rendered in the special component.
   */
};

export function Cart() {
  const [cartData, setData] = useState({
    offerBanner: {},
    cartSection: {},
    sections: {},
    summaryData: {},
  });
  useEffect(() => {
    fetch('http://127.0.0.1:5500/my-scope/assets/cart.json')
      .then((response) => response.json())

      .then((jsonData) => setData(jsonData))

      .catch((error) => console.error('Error:', error));
  }, []);

  const { cart } = useContext(CartContext);
  return (
    <div className="mt-5">
      <OfferBanner offerBanner={cartData.offerBanner} />

      <section className="container py-4 py-lg-5">
        
        <NavLink to="/" className="link">
          <FontAwesomeIcon icon={faAngleLeft} className="me-3"/>Keep Shopping
        </NavLink>
        <h1 className="mb-4 mb-lg-5">{cartData.cartSection.title}</h1>
        <div className="row gy-4 gx-5">
          <div className="col-12 col-md-6 col-lg-8">
            {cart && cart.map((cart1) => <CartItem itemData={cart1} />)}
          </div>
          <div className="col-12 col-md-6 col-lg-4">
            <AddCoupon />
            <hr />
            <Summary summaryData={cartData.summaryData} />
            <div className="d-grid gap-2">
              <button className="btn btn-primary full-width mt-4">
                Proceed To Checkout
              </button>
            </div>
          </div>
        </div>
      </section>
      <hr className="container" />
      {cartData.sections &&
        cartData.sections.length > 0 &&
        cartData.sections.map((section) => (
          <CardSection sectionData={section}></CardSection>
        ))}
    </div>
  );
}
