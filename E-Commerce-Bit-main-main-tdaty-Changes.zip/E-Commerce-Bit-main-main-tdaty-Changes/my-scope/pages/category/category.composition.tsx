import React from 'react';
import { Category } from './category';

export const BasicCategory = () => {
  return (
    <Category>hello world!</Category>
  );
}
