import React, { ReactNode, useContext } from 'react';
import { NavLink, useParams } from 'react-router-dom';
import { useState, useEffect } from 'react';
import { CartContext } from '@my-scope/context.cart';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faAngleLeft,faStar } from '@fortawesome/free-solid-svg-icons';
//import productsData from "../../assets/productData.json";
// import OwlCarousel from 'react-owl-carousel';

interface ProductDetailParams {
  id: string;
  [key: string]: string;
}

interface ProductData {
  title: string;
  buttonText: string;
  imageSrc: string;
  imageAltText: string;
  productId: string;
  productDetails: {
    productName: string;
    category: string;
    averageRating: string;
    totalRatings: string;
    description: string;
    price: string;
    discountPrice: string;
  };
}

export function ProductDetails() {
  const { addToCart } = useContext(CartContext);
  const [isAdded, setIsAdded] =useState(false);
  const handleAddToCart = () => {
    // Assuming productData includes a quantity property
    const productWithQuantity = { ...productData, quantity: 1 };
    
    addToCart(productWithQuantity);
    setIsAdded(true);
  
    setTimeout(() => {
      setIsAdded(false);
    }, 1500);
  };
  const { id } = useParams<ProductDetailParams>();
  const [productData, setProductData] = useState<ProductData | null>(null);
  //setProductData(productDataMock);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('http://127.0.0.1:5500/my-scope/assets/Mock.json')
      .then((response) => response.json())
      .then((jsonData) => {
        const product = jsonData.all_items.find(
          (item: ProductData) => item.productId === id
        );
        setProductData(product || {});
        setLoading(false);
      })
      .catch((error) => {
        console.error('Error:', error);
        setLoading(false);
      });
  }, [id]);

  const [complementaryLooksData, setComplementaryLooksData] = useState({
    complementary: {},
  });
  const [similarCardSectionData, setSimilarCardSectionData] = useState({
    products: {},
  });

  useEffect(() => {
    fetch('http://127.0.0.1:5051/my-scope/assets/complementarylooks.json')
      .then((response) => response.json())
      .then((jsonData) => setComplementaryLooksData(jsonData))
      .catch((error) => console.error('Error:', error));
  }, []);

  useEffect(() => {
    fetch('http://127.0.0.1:5051/my-scope/assets/similar-card-section.json')
      .then((response) => response.json())
      .then((jsonData) => setSimilarCardSectionData(jsonData))
      .catch((error) => console.error('Error:', error));
  }, []);

  const navText = [
    '<i class="prev-btn fas fa-chevron-left"></i>',
    '<i class="next-btn fas fa-chevron-right"></i>',
  ];
  const responsive = {
    0: {
      items: 1,
      nav: false,
    },
    576: {
      items: 1,
      nav: false,
    },
    768: {
      items: 1,
      nav: true,
    },
  };
  if (productData) {
    return (
      <div className="mt-5">
        <section className="container py-4 py-lg-5">
          <div className='mb-4'>
          <NavLink to="/"className="link " >
            <FontAwesomeIcon icon={faAngleLeft} className="me-3"></FontAwesomeIcon>Back to
            previous page
          </NavLink>
          </div>
          <div className="row gy-4 gx-5">
            <div className="col-12 col-md-6 col-lg-4 mb-4">
              <div className="highlight-card">
                <div className="card-image mb-3">
                  <img
                    src={productData.imageSrc}
                    alt={productData.imageAltText}
                  />
                </div>
              </div>
              <div className="thumbnail-carousel mb-2 px-4">
                {/* <OwlCarousel navText={this.navText} items={4} margin={10} loop={true} nav={true}> */}
                {/* <div className="">
                <div className="highlight-card">
                  <div className="card-image mb-3">
                    <img src="https://images.unsplash.com/photo-1619900746827-1484e5f136ca?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8NTZ8fGluZG9vciUyMHBsYW50fGVufDB8fDB8fA%3D%3D&auto=format&fit=crop&w=500&q=60" />
                  </div>
                </div>
              </div> */}
                {/* <div className="">
                <div className="highlight-ccompard">
                  <div className="card-image mb-3">
                    <img src="https://images.unsplash.com/photo-1619900746827-1484e5f136ca?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8NTZ8fGluZG9vciUyMHBsYW50fGVufDB8fDB8fA%3D%3D&auto=format&fit=crop&w=500&q=60" />
                  </div>
                </div>
              </div>
              <div className="">
                <div className="highlight-card">
                  <div className="card-image mb-3">
                    <img src="https://images.unsplash.com/photo-1619900746827-1484e5f136ca?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8NTZ8fGluZG9vciUyMHBsYW50fGVufDB8fDB8fA%3D%3D&auto=format&fit=crop&w=500&q=60" />
                  </div>
                </div>
              </div> */}
                {/* <div className="">
                <div className="highlight-card">
                  <div className="card-image mb-3">
                    <img src="https://images.unsplash.com/photo-1619900746827-1484e5f136ca?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8NTZ8fGluZG9vciUyMHBsYW50fGVufDB8fDB8fA%3D%3D&auto=format&fit=crop&w=500&q=60" />
                  </div>
                </div>
              </div>
              <div className="">
                <div className="highlight-card">
                  <div className="card-image mb-3">
                    <img src="https://images.unsplash.com/photo-1619900746827-1484e5f136ca?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8NTZ8fGluZG9vciUyMHBsYW50fGVufDB8fDB8fA%3D%3D&auto=format&fit=crop&w=500&q=60" />
                  </div>
                </div>
              </div> */}
                {/* </OwlCarousel> */}
              </div>
            </div>

            <div className="col-12 col-md-6 col-lg-8">
              <h1 className="mb-4">{productData.title}</h1>
              <div className="lead">{productData.productDetails.category}</div>
              <div className="d-flex my-4">
                <div className="text-primary me-3">
                  {Array.from(
                    {
                      length: Math.floor(
                        Number(productData.productDetails.averageRating)
                      ),
                    },
                    (_, index) => (
                      <span key={index}>
                        <FontAwesomeIcon icon={faStar}/>
                      </span>
                    )
                  )}
                  {parseFloat(productData.productDetails.averageRating) % 1 !==
                    0 && (
                    <span>
                      <FontAwesomeIcon icon={faStar}/>
                    </span>
                  )}
                </div>
                <div>{productData.productDetails.totalRatings} Ratings</div>
                
              </div>
              <p>{productData.productDetails.description}</p>
              <span className="fs-4 fw-bold mb-5">
                Usually Ships in 2-3 buisness days{' '}
              </span>
              <br />
              <span className="badge bg-info text-dark fs-5 mb-4">Offer</span>
              <div className="fade-price text-decoration-line-through fs-5 mb-1">
                {productData.productDetails.price}
              </div>
              <div className="fs-3 fw-bold mb-5">
                {productData.productDetails.discountPrice}
              </div>
              <button
                className="btn btn-primary me-4"
                onClick={handleAddToCart}>
                <i className="fas fa-shopping-cart me-2"></i>{isAdded?'Added to Cart':'Add to Cart'}
              </button>
              <a className="link">
                <i className="far fa-heart"></i>
              </a>
            </div>
            <div className="col-12">
              <ul className="nav nav-tabs mb-4" id="myTab" role="tablist">
                <li className="nav-item" role="presentation">
                  <button
                    className="nav-link active"
                    id="home-tab"
                    data-bs-toggle="tab"
                    data-bs-target="#home"
                    type="button"
                    role="tab"
                    aria-controls="home"
                    aria-selected="true"
                  >
                    Description
                  </button>
                </li>
                <li className="nav-item" role="presentation">
                  <button
                    className="nav-link"
                    id="profile-tab"
                    data-bs-toggle="tab"
                    data-bs-target="#profile"
                    type="button"
                    role="tab"
                    aria-controls="profile"
                    aria-selected="false"
                  >
                    Reviews
                  </button>
                </li>
              </ul>
              <div className="tab-content" id="myTabContent">
                <div
                  className="tab-pane fade show active"
                  id="home"
                  role="tabpanel"
                  aria-labelledby="home-tab"
                >
                  {productData.productDetails.description}
                </div>
                <div
                  className="tab-pane fade"
                  id="profile"
                  role="tabpanel"
                  aria-labelledby="profile-tab"
                >
                  ...
                </div>
              </div>
            </div>
          </div>
        </section>
        {/* <hr className="container" />
      <CardSection sectionData={similarCardSectionData}></CardSection>
      <hr className="container" />
      {complementaryLooksData.sections && complementaryLooksData.sections.map((section) => (
        <CardSection sectionData={section}></CardSection>
      ))} */}
      </div>
    );
  } else {
    return <div></div>;
  }
}
