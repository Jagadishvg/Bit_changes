import React from 'react';
import { ProductDetails } from './product-details';

export const BasicProductDetails = () => {
  return (
    <ProductDetails>hello world!</ProductDetails>
  );
}
