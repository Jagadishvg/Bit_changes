export { ProductDetails } from './product-details';
export type { ProductDetailsProps } from './product-details';
