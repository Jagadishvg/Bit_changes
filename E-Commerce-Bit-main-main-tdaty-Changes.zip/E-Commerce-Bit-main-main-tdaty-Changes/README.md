# Pull the code and run following commands

1 : $bit init
2 : $bit install
3 : $bit start
