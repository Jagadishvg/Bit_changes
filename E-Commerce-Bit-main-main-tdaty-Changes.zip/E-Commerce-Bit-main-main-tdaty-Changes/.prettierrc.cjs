// bit-generated-prettier-config
module.exports = {
  ...require('./node_modules/.cache/.prettierrc.bit.e4882af8861bcf5b0147891d8b70b40a10428881.cjs')
}